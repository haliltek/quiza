UPDATE `tbl_settings` SET `message` = '2.3.3' WHERE `tbl_settings`.`type` = 'system_version';
CREATE TABLE IF NOT EXISTS `tbl_multi_match_question_reports` ( `id` int(11) NOT NULL AUTO_INCREMENT, `question_id` int(11) NOT NULL, `user_id` int(11) NOT NULL, `message` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL, `date` datetime NOT NULL, PRIMARY KEY (`id`), KEY `question_id` (`question_id`), KEY `user_id` (`user_id`) ) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
ALTER TABLE `tbl_users` ADD `web_fcm_id` VARCHAR(1024) NULL DEFAULT NULL AFTER `fcm_id`;
ALTER TABLE `tbl_users` ADD INDEX(`fcm_id`);
ALTER TABLE `tbl_users` ADD INDEX(`web_fcm_id`);
