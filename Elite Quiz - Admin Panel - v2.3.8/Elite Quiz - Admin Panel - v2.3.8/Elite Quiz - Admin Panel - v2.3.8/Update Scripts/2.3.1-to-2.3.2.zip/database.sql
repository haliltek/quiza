UPDATE `tbl_settings` SET `message` = '2.3.2' WHERE `tbl_settings`.`type` = 'system_version';
ALTER TABLE `tbl_payment_request` ADD `status_date` DATETIME NULL AFTER `date`;
UPDATE `tbl_payment_request` SET `status_date` = `date`;
ALTER TABLE `tbl_users` ADD `app_language` VARCHAR(512) NULL AFTER `api_token`, ADD `web_language` VARCHAR(512) NULL AFTER `app_language`;
INSERT INTO `tbl_settings` (`type`, `message`) SELECT * FROM (SELECT 'guess_the_word_hint_deduct_coin', 1) AS tmp WHERE NOT EXISTS (SELECT type FROM tbl_settings WHERE type  ='guess_the_word_hint_deduct_coin') LIMIT 1;
