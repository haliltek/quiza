UPDATE `tbl_settings` SET `message` = '2.2.6' WHERE `tbl_settings`.`type` = 'system_version';
ALTER TABLE `tbl_fun_n_learn` ADD `content_type` TINYINT NOT NULL DEFAULT '0' AFTER `status`, ADD `content_data` VARCHAR(255) NOT NULL AFTER `content_type`;
ALTER TABLE `tbl_fun_n_learn_question` ADD `image` VARCHAR(250) NOT NULL AFTER `answer`;
