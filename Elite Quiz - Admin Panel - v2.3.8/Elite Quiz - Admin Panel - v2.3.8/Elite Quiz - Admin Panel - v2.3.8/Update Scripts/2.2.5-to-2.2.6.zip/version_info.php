<?php
return array(
'current_version'=>'2.2.5',
    'update_version'=>'2.2.6'
);
