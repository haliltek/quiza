<?php
return array(
'current_version'=>'2.2.4',
    'update_version'=>'2.2.5'
);
