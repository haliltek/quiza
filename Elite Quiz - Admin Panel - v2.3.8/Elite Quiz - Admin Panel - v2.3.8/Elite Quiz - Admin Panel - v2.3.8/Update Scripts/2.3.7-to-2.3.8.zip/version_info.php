<?php
return array(
'current_version'=>'2.3.7',
    'update_version'=>'2.3.8'
);
