UPDATE `tbl_settings` SET `message` = '2.3.8' WHERE `tbl_settings`.`type` = 'system_version';
ALTER TABLE `tbl_category` ADD `has_level` TINYINT NOT NULL DEFAULT '1' AFTER `coins`, ADD INDEX (`has_level`);
ALTER TABLE `tbl_subcategory` ADD `has_level` TINYINT NOT NULL DEFAULT '1' AFTER `coins`, ADD INDEX (`has_level`);
INSERT INTO tbl_settings (`type`, `message`) SELECT * FROM (SELECT 'quiz_zone_total_question', '10') AS tmp WHERE NOT EXISTS (SELECT type FROM tbl_settings WHERE type='quiz_zone_total_question') LIMIT 1;
INSERT INTO tbl_settings (`type`, `message`) SELECT * FROM (SELECT 'multi_match_total_question', '10') AS tmp WHERE NOT EXISTS (SELECT type FROM tbl_settings WHERE type='multi_match_total_question') LIMIT 1;
