UPDATE `tbl_settings` SET `message` = '2.2.4' WHERE `tbl_settings`.`type` = 'system_version';
ALTER TABLE `tbl_notifications` ADD `user_id` LONGTEXT NULL DEFAULT NULL AFTER `users`;
ALTER TABLE `tbl_authenticate` ADD `language` VARCHAR(255) NULL DEFAULT NULL AFTER `status`;
ALTER TABLE `tbl_upload_languages` CHANGE `file` `title` VARCHAR(512) NOT NULL;
ALTER TABLE `tbl_upload_languages` ADD `app_version` VARCHAR(100) NOT NULL DEFAULT '0' AFTER `title`, ADD `web_version` VARCHAR(100) NOT NULL DEFAULT '0' AFTER `app_version`, ADD `app_rtl_support` TINYINT NOT NULL DEFAULT '0' AFTER `web_version`, ADD `web_rtl_support` TINYINT NOT NULL DEFAULT '0' AFTER `app_rtl_support`;
INSERT INTO `tbl_upload_languages` (`id`, `name`, `title`, `app_version`, `web_version`, `app_rtl_support`, `web_rtl_support`) SELECT 1, 'english', 'English', '0.0.1', '0.0.1', 0, 0 WHERE NOT EXISTS ( SELECT 1 FROM `tbl_upload_languages` WHERE `id` = 1 );
