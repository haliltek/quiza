UPDATE `tbl_settings` SET `message` = '2.2.1' WHERE `tbl_settings`.`type` = 'system_version';
INSERT INTO tbl_settings (`type`, `message`) SELECT * FROM (SELECT 'latex_mode', 1) AS tmp WHERE NOT EXISTS (SELECT type FROM tbl_settings WHERE type  ='latex_mode') LIMIT 1;
INSERT INTO tbl_settings (`type`, `message`) SELECT * FROM (SELECT 'exam_latex_mode', 1) AS tmp WHERE NOT EXISTS (SELECT type FROM tbl_settings WHERE type  ='exam_latex_mode') LIMIT 1;
