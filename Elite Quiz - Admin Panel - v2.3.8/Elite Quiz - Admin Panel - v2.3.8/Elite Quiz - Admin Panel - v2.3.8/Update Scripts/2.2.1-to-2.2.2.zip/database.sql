UPDATE `tbl_settings` SET `message` = '2.2.2' WHERE `tbl_settings`.`type` = 'system_version';
