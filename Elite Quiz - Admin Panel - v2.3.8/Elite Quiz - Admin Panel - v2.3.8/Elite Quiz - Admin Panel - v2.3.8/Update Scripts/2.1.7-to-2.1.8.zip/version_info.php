<?php
return array(
'current_version'=>'2.1.7',
    'update_version'=>'2.1.8'
);
