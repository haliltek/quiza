UPDATE `tbl_settings` SET `message` = '2.1.8' WHERE `tbl_settings`.`type` = 'system_version';
