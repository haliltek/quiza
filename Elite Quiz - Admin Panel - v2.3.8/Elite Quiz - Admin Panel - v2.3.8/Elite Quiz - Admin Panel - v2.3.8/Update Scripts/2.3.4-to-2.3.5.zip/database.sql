UPDATE `tbl_settings` SET `message` = '2.3.5' WHERE `tbl_settings`.`type` = 'system_version';
